package com.example.myecommerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
