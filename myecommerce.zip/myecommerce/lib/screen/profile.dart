// import 'dart:io';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:myecommerce/Wiget/button.dart';
// import 'package:myecommerce/Wiget/mytextfield.dart';
// import 'package:myecommerce/model/user.dart';
// import 'package:myecommerce/provider/provider.dart';
// import 'package:myecommerce/screen/homepage.dart';
// import 'package:provider/provider.dart';

// class Profile extends StatefulWidget {
//   static Pattern pattern =
//       r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
//   static Pattern patttern = r'(^(?:[+0]9)?[0-9]{10,12}$)';
//   @override
//   _ProfileState createState() => _ProfileState();
// }

// class _ProfileState extends State<Profile> {
//   UserCredential authResult;
//   File image;
//   var uploadedFileURL;
//   RegExp regex = RegExp(Profile.pattern);
//   RegExp regExp = RegExp(Profile.patttern);
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
//   TextEditingController name;
//   TextEditingController email;
//   TextEditingController password;
//   UserData currentUsers;
//   var uid;
//   bool edit = false;
//   bool cameraChoise = false;
//   var imageMap;
//   Future<String> uploadFile(File _image) async {
//     StorageReference storageReference =
//     FirebaseStorage.instance.ref().child('images/$uid');
//     StorageUploadTask uploadTask = storageReference.putFile(_image);
//     StorageTaskSnapshot task = await uploadTask.onComplete;
//     final String _imageUrl = await task.ref.getDownloadURL();
//     return _imageUrl;
//   }
//   Widget textContainer({@required String name}) {
//     return Container(
//       width: double.infinity,
//       height: 60,
//       decoration: BoxDecoration(
//         color: Colors.grey,
//         borderRadius: BorderRadius.circular(10.0),
//       ),
//       child: Center(
//         child: Text(
//           name,
//           style: TextStyle(
//             fontSize: 20,
//             color: Colors.white,
//           ),
//         ),
//       ),
//     );
//   }
//   Widget textField({@required String name}) {
//     return TextFormField(
//       decoration: InputDecoration(
//         filled: true,
//         fillColor: Colors.grey,
//         hintText: name,
//         hintStyle: TextStyle(
//           color: Colors.white,
//         ),
//         border: OutlineInputBorder(
//           borderSide: BorderSide.none,
//           borderRadius: BorderRadius.circular(10.0),
//         ),
//       ),
//     );
//   }
//   void userDataUpdate() async {
//     image != null ? imageMap = await uploadFile(image) : Container();
//     FirebaseFirestore.instance.collection("user").doc(uid).update({
//       "FullName": name.text,
//       "Email": email.text,
//       "password": password.text,
//       "imageUrl": image == null ? currentUsers.image : imageMap,
//     });
//   }
//   Future<void> alart(context) {
//     return showDialog(
//         context: context,
//         builder: (context) {
//           return AlertDialog(
//             title: Text("Choose an action"),
//             content: SingleChildScrollView(
//               child: ListBody(
//                 children: [
//                   GestureDetector(
//                     child: Text("Gallery"),
//                     onTap: () {
//                       getCameraImage(ImageSource.gallery);
//                    //   Navigator.of(context).pop();
//                     },
//                   ),
//                   Padding(padding: EdgeInsets.all(8.0)),
//                   GestureDetector(
//                     child: Text("Camera"),
//                     onTap: () {
//                       getCameraImage(ImageSource.camera);
//                      // Navigator.of(context).pop();
//                     },
//                   )
//                 ],
//               ),
//             ),
//           );
//         });
//   }
//   Future getCameraImage(ImageSource choise) async {
//     final pickedFile = await ImagePicker().getImage(source: choise);
//     setState(() {
//       image = File(pickedFile.path);
//     });
//     Navigator.of(context).pop();
//   }
//   function() {
//     if (name.text.isEmpty && email.text.isEmpty && password.text.isEmpty) {
//       _scaffoldKey.currentState.showSnackBar(
//         SnackBar(
//           content: Text('All field is emtpy'),
//           backgroundColor: Theme.of(context).accentColor,
//         ),
//       );
//       return;
//     }
//     if (name.text.trim().isEmpty || name.text.trim() == null) {
//       _scaffoldKey.currentState.showSnackBar(
//         SnackBar(
//           content: Text('Full Name is empty'),
//           backgroundColor: Theme.of(context).accentColor,
//         ),
//       );
//       return;
//     }
//     if (email.text.trim().isEmpty || email.text.trim() == null) {
//       _scaffoldKey.currentState.showSnackBar(
//         SnackBar(
//           content: Text('Email is empty'),
//           backgroundColor: Theme.of(context).accentColor,
//         ),
//       );
//       return;
//     } else if (!regex.hasMatch(email.text)) {
//       _scaffoldKey.currentState.showSnackBar(
//         SnackBar(
//           content: Text('Please Enter Valid Email'),
//           backgroundColor: Theme.of(context).primaryColor,
//         ),
//       );
//       return;
//     } else {
//       setState(() {
//         edit = false;
//         userDataUpdate();
//         uploadFile(image);
//       });
//     }
//   }

//   Widget build(BuildContext context) {
//     MyProvider myProvider = Provider.of<MyProvider>(context);
//     myProvider.fetchUserData();
//     currentUsers = myProvider.getCurrrentUser;
//     email = TextEditingController(text: currentUsers.email);
//     name = TextEditingController(text: currentUsers.fullname);
//     password = TextEditingController(text: currentUsers.password);
//     return Scaffold(
//       key: _scaffoldKey,
//       resizeToAvoidBottomInset: false,
//       appBar: AppBar(
//         elevation: 0.0,
//         actions: [
//           IconButton(
//             icon: Icon(Icons.edit),
//             onPressed: () {
//               setState(() {
//                 edit = true;
//               });
//             },
//           ),
//         ],
//         leading: edit == false
//             ? IconButton(
//                 icon: Icon(
//                   Icons.arrow_back,
//                   color: Colors.black,
//                 ),
//                 color: Colors.white,
//                 onPressed: () {
//                   Navigator.of(context).pushReplacement(
//                     MaterialPageRoute(
//                       builder: (context) => HomePage(),
//                     ),
//                   );
//                 },
//               )
//             : IconButton(
//                 icon: Icon(Icons.close),
//                 onPressed: () {
//                   setState(
//                     () {
//                       edit = false;
//                     },
//                   );
//                 },
//               ),
//       ),
//       backgroundColor: Theme.of(context).primaryColor,
//       body: SafeArea(
//         child: Column(
//           children: [
//             Expanded(
//               child: Container(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     GestureDetector(
//                       onTap: () {
//                         edit == true ? alart(context) : Container();
//                       },
//                       child: CircleAvatar(
//                         backgroundColor: Colors.lightBlue,
//                         maxRadius: 65,
//                         child: CircleAvatar(
//                           backgroundImage: image == null
//                               ? currentUsers.image == null
//                                 ? AssetImage('images/imageprofile.png')
//                                 : NetworkImage(currentUsers.image)
//                               : FileImage(image),
//                           maxRadius: 60,
//                         ),
//                       ),
//                     ),
//                     SizedBox(height: 10),
//                     Text(
//                       currentUsers.fullname,
//                       style: TextStyle(
//                           fontSize: 20,
//                           fontWeight: FontWeight.bold,
//                           color: Colors.lightBlue),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//             Expanded(
//               flex: 2,
//               child: Container(
//                 child: Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 20),
//                   child: edit == true
//                       ? Column(
//                           children: [
//                             Container(
//                               height: 320,
//                               child: Column(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.spaceEvenly,
//                                 children: [
//                                   MYTextField(
//                                     controller: name,
//                                     eyeicon: null,
//                                     hintText: 'Name',
//                                     keyboard: TextInputType.name,
//                                     obscuretext: false,
//                                   ),
//                                   MYTextField(
//                                     controller: email,
//                                     eyeicon: null,
//                                     hintText: 'Email',
//                                     keyboard: TextInputType.name,
//                                     obscuretext: false,
//                                   ),
//                                   MYTextField(
//                                     controller: password,
//                                     eyeicon: Icons.remove_red_eye,
//                                     hintText: 'Password',
//                                     keyboard: TextInputType.name,
//                                     obscuretext: false,
//                                   ),
//                                 ],
//                               ),
//                             ),
//                             Button(
//                               textcolor: Colors.white,
//                               tittle: 'Update',
//                               whenpress: () {
//                                 function();
//                               },
//                               buttoncolors: Colors.blue,
//                             )
//                           ],
//                         )
//                       : Column(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//                             Container(
//                               height: 320,
//                               child: Column(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.spaceEvenly,
//                                 children: [
//                                   textContainer(
//                                     name: currentUsers.fullname,
//                                   ),
//                                   textContainer(
//                                     name: currentUsers.email,
//                                   ),
//                                   textContainer(
//                                     name: currentUsers.password.toString(),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ],
//                         ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
