import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  Widget _singleContainer({@required context}) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              blurRadius: 7,
              color: Colors.grey[300].withOpacity(0.5),
              offset: Offset(0, 3),
              spreadRadius: 4,
            )
          ]),
      child: Padding(
        padding: EdgeInsets.only(top: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 90,
              decoration: BoxDecoration(
                color: Colors.white,
                image: DecorationImage(
                  image: AssetImage('images/Cookie Cream.png'),
                ),
              ),
            ),
            Text(
              '\$ 29',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor),
            ),
            Text(
              'Cookie Cream',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black54,
              ),
            ),
            Divider(
              thickness: 2,
            ),
            Padding(
              padding: const EdgeInsets.all(11.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.remove_circle_outline,
                    color: Theme.of(context).primaryColor,
                  ),
                  Text("3",style: TextStyle(fontSize: 23,color: Theme.of(context).primaryColor),),
                  Icon(
                    Icons.add_circle_outline,
                    color: Theme.of(context).primaryColor,
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _datailContainer(
      {@required String image,
      @required String name,
      @required double price,
      @required Function whenPress,
      @required context}) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              blurRadius: 7,
              color: Colors.grey[300].withOpacity(0.5),
              offset: Offset(0, 3),
              spreadRadius: 4,
            )
          ]),
      child: Padding(
        padding: EdgeInsets.only(top: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 90,
              decoration: BoxDecoration(
                color: Colors.white,
                image: DecorationImage(
                  image: AssetImage(image),
                ),
              ),
            ),
            Text(
              '\$ $price',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor),
            ),
            Text(
              '$name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black54,
              ),
            ),
            Divider(
              thickness: 2,
            ),
            RaisedButton.icon(
              splashColor: Colors.white,
              elevation: 0.0,
              color: Colors.white,
              onPressed: whenPress,
              icon: Icon(
                Icons.shopping_cart,
                size: 21,
                color: Theme.of(context).primaryColor,
              ),
              label: Text(
                "Add to Cart",
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.white,
        leading: Icon(
          Icons.arrow_back_ios,
          color: Colors.black54,
          size: 35,
        ),
        centerTitle: true,
        title: Text(
          "Pickup",
          style: TextStyle(
            fontSize: 22,
            color: Colors.black54,
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.all(8),
            child: Icon(
              Icons.notifications_none,
              color: Theme.of(context).primaryColor,
              size: 28,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Categories",
                      style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.w400,
                        letterSpacing: 2,
                      ),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Cookies",
                          style: TextStyle(
                            fontSize: 20,
                            color: Theme.of(context).primaryColor,
                            fontWeight: FontWeight.w400,
                            letterSpacing: 2,
                          ),
                        ),
                        Text(
                          "Cookies",
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.black54,
                            fontWeight: FontWeight.w400,
                            letterSpacing: 2,
                          ),
                        ),
                        Text(
                          "Cookies",
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.black54,
                            fontWeight: FontWeight.w400,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              color: Colors.grey[200].withOpacity(0.5),
              child: Padding(
                padding: EdgeInsets.all(8),
                child: GridView.count(
                  crossAxisCount: 2,
                  childAspectRatio: 0.8,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  children: [
                    _datailContainer(
                        context: context,
                        image: 'images/Cookie Mint.png',
                        name: 'Cookie Mint',
                        price: 30.2,
                        whenPress: () {}),
                    _singleContainer(context: context),
                    _datailContainer(
                        context: context,
                        image: 'images/Cookie Classic.png',
                        name: 'Cookie Classic',
                        price: 40.2,
                        whenPress: () {}),
                    _datailContainer(
                        context: context,
                        image: 'images/Cookie Choco.png',
                        name: 'Cookie Choco',
                        price: 49.2,
                        whenPress: () {}),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
