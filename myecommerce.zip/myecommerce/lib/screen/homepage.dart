// import 'package:flutter/material.dart';
// import 'package:carousel_pro/carousel_pro.dart';
// import 'package:myecommerce/Wiget/appbar.dart';
// import 'package:myecommerce/Wiget/childfuction.dart';
// import 'package:myecommerce/Wiget/drawercontainer.dart';
// import 'package:myecommerce/Wiget/drawerwidget.dart';
// import 'package:myecommerce/Wiget/fraturedcontainer.dart';
// import 'package:myecommerce/Wiget/manfuction.dart';
// import 'package:myecommerce/Wiget/womanfuction.dart';
// import 'package:myecommerce/model/user.dart';
// import 'package:myecommerce/provider/categoryprovider.dart';
// import 'package:myecommerce/provider/provider.dart';
// import 'package:myecommerce/screen/category.dart';
// import 'package:provider/provider.dart';
// class HomePage extends StatefulWidget {
//   @override
//   _HomePageState createState() => _HomePageState();
// }

// class _HomePageState extends State<HomePage> {
//   Widget callDrawerContainer({@required IconData icon,@required String tittle,@required Function ontap, context}) {
//     return GestureDetector(
//       onTap: ontap,
//       child: DrawerContainer(
//         icon: icon,
//         tittle: tittle,
//       ),
//     );
//   }
//   var uid;
//   UserData userData;
//   Widget build(BuildContext context) {
//     MyProvider provider = Provider.of<MyProvider>(context);
//     provider.allgetProduct();
//     provider.getSeeAllProduct();
//     MyCategory category = Provider.of<MyCategory>(context);
//     category.allgetChildProduct();
//     category.allgetManProduct();
//     category.allgetWomanProduct();
//     category.allgetChildCategories();
//     category.allgetManCategories();
//     category.allgetWomanCategories();
//     return Scaffold(
//       drawer: DrawerWidget(),
//       backgroundColor: Theme.of(context).primaryColor,
//       appBar: appBar(context),
//       body: RefreshIndicator(
//         color: Colors.red,
//         backgroundColor: Colors.black,
//         onRefresh: () async {
//           return await Future.delayed(
//             Duration(
//               seconds: 3,
//             ),
//           );
//         },
//         child: Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
//           child: Column(
//             children: <Widget>[
//               Expanded(
//                 child: Container(
//                   child: Carousel(
//                     showIndicator: false,
//                     images: [
//                       AssetImage('images/iphone.jpeg'),
//                       AssetImage('images/huawei.jpg'),
//                       AssetImage('images/opp.jpg'),
//                     ],
//                   ),
//                 ),
//               ),
//               Expanded(
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: <Widget>[
//                     ListTile(
//                       leading: Text(
//                         "Categories",
//                         style: TextStyle(
//                           color: Theme.of(context).textSelectionColor,
//                         ),
//                       ),
//                     ),
//                     SingleChildScrollView(
//                       scrollDirection: Axis.horizontal,
//                       child: Container(
//                         width: 400,
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                           children: <Widget>[
//                             ChildFuction(),
//                             ManFuction(),
//                             WomanFuction(),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Expanded(
//                 flex: 2,
//                 child: Container(
//                   child: Column(
//                     children: <Widget>[
//                       ListTile(
//                         leading: Text(
//                           "Featured",
//                           style: TextStyle(
//                               color: Theme.of(context).textSelectionColor),
//                         ),
//                         trailing: InkWell(
//                           onTap: () {
//                             Navigator.of(context).push(
//                               MaterialPageRoute(
//                                 builder: (context) => Category(
//                                   list: provider.getSeenAllProduct,
//                                 ),
//                               ),
//                             );
//                           },
//                           child: Text(
//                             "see All",
//                             style: TextStyle(
//                                 color: Theme.of(context).textSelectionColor),
//                           ),
//                         ),
//                       ),
//                       Container(
//                         height: 300,
//                         width: 500,
//                         child: BottomPartContainer(),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
