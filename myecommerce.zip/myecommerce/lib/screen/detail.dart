import 'package:flutter/material.dart';
import 'package:myecommerce/provider/provider.dart';
import 'package:myecommerce/screen/CheckOut.dart';

import 'package:myecommerce/screen/homescreen.dart';
import 'package:provider/provider.dart';

class Detail extends StatefulWidget {
  final String image;
  final String tittle;
  final double price;
  Detail({@required this.image, @required this.price, @required this.tittle});
  @override
  _DetailState createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  int count = 1;
  double totalPrice;
  List<bool> _size = List.generate(3, (_) => false);
  List<bool> _color = List.generate(3, (_) => false);

  int colorIndex = 0;
  String color;
  void getColor() {
    if (colorIndex == 0) {
      setState(() {
        color = "Blue";
      });
    } else if (colorIndex == 1) {
      setState(() {
        color = "Green";
      });
    } else if (colorIndex == 2) {
      setState(() {
        color = "Pink";
      });
    }
  }

  int sizeIndex = 0;
  String size;
  void getSize() {
    if (sizeIndex == 0) {
      setState(() {
        size = "1";
      });
    } else if (sizeIndex == 1) {
      setState(() {
        size = "2";
      });
    } else if (sizeIndex == 2) {
      setState(() {
        size = "3";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (totalPrice == null) {
      totalPrice = widget.price;
    }
    MyProvider myProvider = Provider.of<MyProvider>(context);
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (context) => HomeScreen(),
              ),
            );
          },
        ),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(widget.image),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      widget.tittle,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Container(
                      height: 35,
                      width: 100,
                      decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(10.0)),
                      child: Center(
                        child: Text(
                          "\$$totalPrice",
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text("Stay stylish or refresh your styles with this"),
                    Text("seasons new ECCO shoes .boots ans hags")
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Text("Size Range"),
                    ToggleButtons(
                      borderColor: Colors.grey,
                      disabledColor: Colors.grey,
                      highlightColor: Colors.pink,
                      fillColor: Colors.black12,
                      children: <Widget>[
                        Text("1"),
                        Text("2"),
                        Text("3"),
                      ],
                      isSelected: _size,
                      onPressed: (index) {
                        setState(
                          () {
                            for (var i = 0; i < _size.length; i++) {
                              if (i == index) {
                                _size[i] = true;
                              } else {
                                _size[i] = false;
                              }
                            }
                          },
                        );
                        setState(() {
                          sizeIndex = index;
                        });
                      },
                    ),
                  ],
                ),
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.remove),
                      onPressed: () {
                        setState(
                          () {
                            if (count > 1) {
                              count--;
                              totalPrice = count * widget.price;
                            }
                          },
                        );
                      },
                    ),
                    Text(count.toString()),
                    IconButton(
                      icon: Icon(Icons.add),
                      onPressed: () {
                        setState(
                          () {
                            count++;
                            totalPrice = count * widget.price;
                          },
                        );
                      },
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20, bottom: 20),
                  child: Row(
                    children: <Widget>[
                      Text("Colros"),
                      Container(
                        height: 25,
                        width: 200,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            ToggleButtons(
                              borderColor: Colors.grey,
                              disabledColor: Colors.grey,
                              highlightColor: Colors.pink,
                              fillColor: Colors.black12,
                              children: <Widget>[
                                CircleAvatar(
                                  backgroundColor: Colors.blue,
                                ),
                                CircleAvatar(
                                  backgroundColor: Colors.green,
                                ),
                                CircleAvatar(
                                  backgroundColor: Colors.pink,
                                ),
                              ],
                              isSelected: _color,
                              onPressed: (index) {
                                setState(() {
                                  for (var i = 0; i < _color.length; i++) {
                                    if (i == index) {
                                      _color[i] = true;
                                    } else {
                                      _color[i] = false;
                                    }
                                  }
                                });
                                setState(() {
                                  colorIndex = index;
                                });
                              },
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text("FABRIC"),
                    Text("Yak Later"),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    height: 60,
                    width: double.infinity,
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0)),
                      color: Colors.green,
                      child: Text(
                        "Add To Cart",
                        style: TextStyle(color: Colors.white, fontSize: 25),
                      ),
                      onPressed: () {
                        getColor();
                        getSize();
                        myProvider.addCartProduct(
                          image: widget.image,
                          price: widget.price,
                          tittle: widget.tittle,
                          que: count,
                          color: color,
                          size: size,
                        );
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => CheckOut(),
                          ),
                        );
                      },
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
