// import 'package:flutter/material.dart';
// import 'package:myecommerce/Wiget/cartwidget.dart';
// import 'package:myecommerce/screen/CheckOut.dart';
// import 'package:myecommerce/screen/homepage.dart';
// import 'package:provider/provider.dart';
// import '../provider/provider.dart';
// class Cart extends StatefulWidget {
//   @override
//   _CartState createState() => _CartState();
// }
// class _CartState extends State<Cart> {
//   double total = 0.0;
//   @override
//   void initState() {
//     MyProvider provider = Provider.of<MyProvider>(context, listen: false);
//     var pricepeice = provider.cartProductlist;
//     pricepeice.forEach(
//       (element) {
//         total += element.price;
//       },
//     );
//     super.initState();
//   }
//   Widget build(BuildContext context) {
//     MyProvider provider = Provider.of<MyProvider>(context);
//     return Scaffold(
//       backgroundColor: Theme.of(context).primaryColor,
//       appBar: AppBar(
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () {
//             Navigator.of(context).pushReplacement(
//                 MaterialPageRoute(builder: (context) => HomePage()));
//           },
//         ),
//         elevation: 0.0,
//         centerTitle: true,
//         title: Text("Cart"),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.symmetric(horizontal: 20),
//         child: Column(
//           children: <Widget>[
//             Expanded(
//               flex: 3,
//               child: ListView.builder(
//                 itemCount: provider.cartProductLength,
//                 itemBuilder: (context, index) => CartWidget(
//                   price: provider.cartProductlist[index].price,
//                   image: provider.cartProductlist[index].image,
//                   title: provider.cartProductlist[index].tittle,
//                 ),
//               ),
//             ),
//             Expanded(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                 children: <Widget>[
//                   Divider(
//                     color: Colors.black,
//                   ),
//                   ListTile(
//                     leading: Column(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: <Widget>[
//                         Text(
//                           "Total",
//                           style: TextStyle(color: Colors.green),
//                         ),
//                         Text(
//                           '\$${total.toStringAsFixed(2)}',
//                           style: TextStyle(
//                               fontWeight: FontWeight.bold, fontSize: 20),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Container(
//                     height: 60,
//                     width: double.infinity,
//                     child: RaisedButton(
//                       shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(15.0)),
//                       color: Colors.green,
//                       child: Text(
//                         "CHECKOUT",
//                         style: TextStyle(
//                           fontSize: 25,
//                           color: Colors.white,
//                         ),
//                       ),
//                       onPressed: () {
                        
//                       },
//                     ),
//                   )
//                 ],
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
