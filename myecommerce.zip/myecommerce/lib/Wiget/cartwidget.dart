import 'package:flutter/material.dart';
import 'package:myecommerce/provider/provider.dart';
import 'package:provider/provider.dart';

class CartWidget extends StatefulWidget {
  final String image;
  final double price;
  final String title;
  final int que;
  final String color;
  final String size;
  CartWidget({
    @required this.price,
    @required this.color,
    @required this.size,
    @required this.image,
    @required this.title,
    @required this.que,
  });
  @override
  _CartWidgetState createState() => _CartWidgetState();
}

class _CartWidgetState extends State<CartWidget> {
  double m;
  Widget dismissible() {
    MyProvider provider = Provider.of<MyProvider>(context);
    return Dismissible(
      key: UniqueKey(),
      onDismissed: (DismissDirection direction) {
        setState(() {
          provider.delete();
        });
      },
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 20),
        height: 100,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30.0),
          color: Colors.grey[300],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(widget.image),
                ),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20.0),
                  bottomLeft: Radius.circular(20.0),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(widget.title),
                SizedBox(
                  height: 10,
                ),
                Text('\$ $total'),
                SizedBox(
                  height: 10,
                ),
                Text('Colors ${widget.color}'),
                Text('Size ${widget.size}')
              ],
            ),
            Text('x ${widget.que}')
          ],
        ),
      ),
    );
  }
  double total;
  @override
  Widget build(BuildContext context) {
    MyProvider provider = Provider.of<MyProvider>(
      context,
      listen: false,
    );
    var pricepeice = provider.cartProductlist;
    pricepeice.forEach(
      (element) {
        total = element.price * widget.que;
      },
    );
    return dismissible();
  }
}
