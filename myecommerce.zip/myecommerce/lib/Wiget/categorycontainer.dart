// import 'package:flutter/material.dart';

// class CategoryContainer extends StatelessWidget {
//   final String image;
//   final String tittle;
//   final Function onTap;
//   CategoryContainer({this.image, this.tittle, this.onTap});
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: <Widget>[
//         GestureDetector(
//           onTap: onTap,
//           child: Column(
//             children: <Widget>[
//               Container(
//                 height: 80,
//                 width: 100,
//                 decoration: BoxDecoration(
//                   image: DecorationImage(
//                   fit: BoxFit.cover, image: NetworkImage(image)),
//                   color: Colors.blue,
//                   borderRadius: BorderRadius.circular(10.0),
//                 ),
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               Text(tittle, style: TextStyle(color: Colors.white,fontWeight: FontWeight.w400))
//             ],
//           ),
//         )
//       ],
//     );
//   }
// }
import 'package:flutter/material.dart';

class MiddlePart extends StatelessWidget {
  final String tittle;
  final String image;
  final Function onTap;
  MiddlePart(
      {@required this.image, @required this.tittle, @required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            margin: EdgeInsets.only(right: 20),
            height: 170,
            width: 140,
            decoration: BoxDecoration(
              image: DecorationImage(
                fit: BoxFit.cover,
                image: NetworkImage(image),
              ),
              boxShadow: [
                BoxShadow(
                  blurRadius: 0.3,
                  offset: Offset(0, 1),
                  color: Colors.grey,
                ),
              ],
              color: Color(0xfff2f2f2),
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        Text(
          tittle,
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.normal,
          ),
        ),
      ],
    );
  }
}
