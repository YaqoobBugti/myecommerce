// import 'package:flutter/material.dart';
// import 'package:myecommerce/Wiget/featured.dart';
// import 'package:myecommerce/model/product.dart';
// import 'package:myecommerce/provider/categoryprovider.dart';
// import 'package:myecommerce/screen/detail.dart';
// import 'package:provider/provider.dart';

// class ManCategories extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     MyCategory manCatagories = Provider.of(context);
//     List<Product> setManCategories = manCatagories.getallManCategories;
//     return GridView.count(
//       childAspectRatio: 0.69,
//       crossAxisCount: 2,
//       padding: EdgeInsets.only(left: 20),
//       children: setManCategories.map(
//         (element) {
//           return Featured(
//             ontap: () {
//               Navigator.of(context).push(
//                 MaterialPageRoute(
//                   builder: (context) => Detail(
//                     image: element.image,
//                     price: element.price,
//                     tittle: element.tittle,
//                   ),
//                 ),
//               );
//             },
//             image: element.image,
//             price: element.price,
//             tittle: element.tittle,
//           );
//         },
//       ).toList(),
//     );
//   }
// }
