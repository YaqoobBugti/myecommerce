import 'package:flutter/material.dart';
class Categories{
  final String image;
  final String tittle;
  Categories({@required this. image,@required this.tittle});
}