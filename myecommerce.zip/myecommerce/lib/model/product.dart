import 'package:flutter/material.dart';
class Product {
  final String image;
  final double price;
  final String tittle;
  Product({@required this. image,@required this.price,@required this.tittle});
}